#' @title Square the input
#' @param x Vector of numerics
#' @return The vector x, squared.
#' @export
square <- function(x) x^2
